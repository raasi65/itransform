package com.cg.string;

public class StringBufferAppend {

		public static void main(String[] args) {
			StringBuffer sb = new StringBuffer();
			sb.append("StringBuffer");
			sb.append(" is a peer class of String");
			sb.append(" that provide much of");
			sb.append(" the functionality of strings");
			System.out.println(sb);
		}


}
