package com.cg.oops.Q4;

public class Derived_Class extends Main{
		//in chaild class we need to provide implementation to abstract method
			@Override
			public void meth() {
				// TODO Auto-generated method stub
				
			}



}
