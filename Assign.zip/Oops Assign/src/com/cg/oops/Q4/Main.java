package com.cg.oops.Q4;

public abstract class Main {


	//a class is either public or default
	//final class is not supported for inheritance ,when we cant inherit it then hoe provide implementation for abstract method ,
	//abstract class not a final
	
		 //if a class contain abstract method then class must be abstract
			public abstract void meth();
	
}
