package com.cg.oops.Q5;


class cube extends Shape{


@Override
void draw() {



System.out.println("It is in cube shape");

}

}