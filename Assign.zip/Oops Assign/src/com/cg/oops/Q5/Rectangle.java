package com.cg.oops.Q5;

	class Rectangle extends Shape{

		@Override
		void draw() {
		System.out.println("It is in Rectangle shape");

		}

		
}
