package com.Assgn.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Assgn.Model.EmpModel;



@Repository
public interface EmpRepository  extends CrudRepository<EmpModel, String>{

}
