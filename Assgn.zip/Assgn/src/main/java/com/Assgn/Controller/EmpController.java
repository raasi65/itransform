package com.Assgn.Controller;

import java.util.ArrayList;
import java.util.Collections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.Assgn.Model.EmpModel;
import com.Assgn.service.EmpService;


@RestController
@RequestMapping("/employee")
public class EmpController {
	
	@Autowired
	EmpService service;
	
	@GetMapping("/findall")
	public ArrayList<EmpModel> findAll(){
    ArrayList<EmpModel> list=service.findall();
    ArrayList sortedList=new ArrayList();
    for(int i=0;i<list.size();i++) {
    	sortedList.add(list.get(i).getName());
    }
    Collections.sort(sortedList);
	return sortedList;
	}
}
	
	