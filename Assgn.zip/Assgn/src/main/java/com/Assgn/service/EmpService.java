package com.Assgn.service;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Assgn.Model.EmpModel;
import com.Assgn.repository.EmpRepository;

@Service
public class EmpService {
	@Autowired
	EmpRepository repo;
	
	public ArrayList<EmpModel> findall(){
		return (ArrayList<EmpModel>)repo.findAll();
		
	}

}
